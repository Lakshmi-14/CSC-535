/*
* Assignment 6 : Demonstration of important OOPS concepts including inheritance, polymorphism, concrete vs abstract classes and interfaces.
* @author AshokAjmeera
* @version 1.0 
* Execution: java ShapeCollection
*/


//package main;

import java.util.Scanner;

public class RectangularSolid implements ThreeDShape {

	private int length;
	private int breadth;
	private int height;

	public RectangularSolid() {
	}

	public RectangularSolid(int length, int breadth, int height) {
		this.length = length;
		this.breadth = breadth;
		this.height = height;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public double getSurfaceArea() {
		return 2D * (length * breadth + breadth * height + height * length);
	}

	@Override
	public double getVolume() {
		return length * breadth * height;
	}
	
	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter Length: ");
		setLength(sc.nextInt());

		System.out.println("Enter Breadth: ");
		setBreadth(sc.nextInt());

		System.out.println("Enter Height: ");
		setHeight(sc.nextInt());
		
	}

	@Override
	public String toString() {
		return "RectangularSolid [SurfaceArea=" + getSurfaceArea() + ", Volume=" + getVolume() + "]";
	}
	
	public static void main(String[] args){
		RectangularSolid c1 = new RectangularSolid();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println("\nThe RectangularSolid properties are : ");
		System.out.println(c1.toString());
		return ;
	}
	

}
