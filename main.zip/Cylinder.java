//package main;

import java.util.Scanner;

public class Cylinder implements ThreeDShape {

	private int radius;
	private int height;

	public Cylinder() {
	}

	public Cylinder(int radius, int height) {
		this.radius = radius;
		this.height = height;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public double getSurfaceArea() {
		return 2D * Math.PI * radius * (radius + height);
	}

	@Override
	public double getVolume() {
		// TODO Auto-generated method stub
		return Math.PI * radius * radius * height;
	}

	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter radius: ");
		setRadius(sc.nextInt());

		System.out.println("Enter Height: ");
		setHeight(sc.nextInt());

	}
	
	@Override
	public String toString() {
		return "Cylinder [ " + "Surface Area=" + getSurfaceArea() + ", Volume=" + getVolume() + "]";
	}
	
	public static void main(String[] args){
		Cylinder c1 = new Cylinder();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println("\nThe Cylinder properties are : ");
		System.out.println(c1.toString());
		return ;
	}

}
