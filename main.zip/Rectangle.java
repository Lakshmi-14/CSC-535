/*
* Assignment 6 : Demonstration of important OOPS concepts including inheritance, polymorphism, concrete vs abstract classes and interfaces.
* @author AshokAjmeera
* @version 1.0 
* Execution: java ShapeCollection
*/


//package main;

import java.util.Scanner;

public class Rectangle implements TwoDShape {

	@Override
	public String toString() {
		return "Rectangle [Area=" + getArea() + ", Perimeter=" + getPerimeter() + "]";
	}

	private int length;
	private int breadth;

	public Rectangle() {
	}

	public Rectangle(int length, int breath) {
		this.length = length;
		this.breadth = breath;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	@Override
	public double getArea() {
		return getLength() * getBreadth();
	}

	@Override
	public double getPerimeter() {
		return (getBreadth() + getLength()) * 2D;
	}

	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter Length: ");
		setLength(sc.nextInt());

		System.out.println("Enter Breadth: ");
		setBreadth(sc.nextInt());
		

	}
	
	public static void main(String[] args){
		Rectangle c1 = new Rectangle();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println("\nThe Rectangle properties are : ");
		System.out.println(c1.toString());
		return ;
	}
}
