//package main;

import java.util.Scanner;

public class Triangle implements TwoDShape {
	private int base;
	private int height;

	private int a, b, c;

	@Override
	public double getArea() {
		return 0.5D * height * base;
	}

	@Override
	public double getPerimeter() {
		return a + b + c;
	}

	public Triangle(int base, int height, int a, int b, int c) {
		this.base = base;
		this.height = height;
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public Triangle() {
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter base: ");
		setBase(sc.nextInt());
		
		System.out.println("Enter Height: ");
		setHeight(sc.nextInt());
		
		System.out.println("Enter side A: ");
		setA(sc.nextInt());
	
		System.out.println("Enter side B: ");
		setB(sc.nextInt());
		
		System.out.println("Enter side C: ");
		setC(sc.nextInt());
	}

	@Override
	public String toString() {
		return "Traingle [Area=" + getArea() + ", Perimeter=" + getPerimeter() + "]";
	}
	
	public static void main(String[] args){
		Triangle c1 = new Triangle();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println("\nThe Triangle properties are : ");
		System.out.println(c1.toString());
		return ;
	}
	

}
