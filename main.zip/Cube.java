//package main;

import java.util.Scanner;

public class Cube implements ThreeDShape {
	private int side;

	public Cube() {
	}

	public Cube(int side) {
		this.side = side;
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}

	@Override
	public double getSurfaceArea() {
		return 6D * side * side;
	}

	@Override
	public double getVolume() {
		return side * side * side;
	}

	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter side: ");
		setSide(sc.nextInt());
	}

	@Override
	public String toString() {
		return "Cube [ " + "Surface Area=" + getSurfaceArea() + ", Volume=" + getVolume() + "]";
	}
	
	public static void main(String[] args){
		Cube c1 = new Cube();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println("\nThe Cube properties are : ");
		System.out.println(c1.toString());
		return ;
	}

}
