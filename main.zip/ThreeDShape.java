//package main;

public interface ThreeDShape extends Shape {

	public double getSurfaceArea();
	public double getVolume();
}
