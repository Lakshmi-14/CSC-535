//package main;

public enum Shapes {

	CIRCLE("1"), RECTANGLE("2"), TRIANGLE("3"),

	CUBE("4"), RECTANGULAR_SOLID("5"), CYLINDER("6");

	private String index;

	Shapes(String index) {
		this.index = index;
	}

	public String getIndex() {
		return index;
	}

}
