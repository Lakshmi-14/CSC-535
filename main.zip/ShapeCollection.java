/*
* Assignment 6 : Demonstration of important OOPS concepts including inheritance, polymorphism, concrete vs abstract classes and interfaces.
* @author AshokAjmeera
* @version 1.0 
* Execution: java ShapeCollection
*/



//package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ShapeCollection {

	private List<Shape> shapes;
	private Scanner sc;
	private Shapes availableShapes[] = Shapes.values();

	public ShapeCollection() {
		shapes = new ArrayList<>();
		sc = new Scanner(System.in);
	}

	public static void main(String[] args) {
		ShapeCollection shapeCollection = new ShapeCollection();
		shapeCollection.displayMenuAndReadInput();
		shapeCollection.sc.close();
	}

	public void displayMenuAndReadInput() {
//		Shape s = new Circle() ;
//		
//		System.out.println( s instanceof TwoDShape);

		do {
			System.out.println("Select from below options:\n1. Add Shape\n2. Display All Information of shapes added\n"
					+ "3. Display All Information of 2D shapes\n4. Display All Information of 3D shapes\n"
					+ "5. Display All Information of Specific Shapes\n6. Remove shape by index.\n7. Exit");

			int input = sc.nextInt();
			
			switch (input) {
			case 1:
				addShape();
				break;
			case 2:
				System.out.println("Information of all shapes added");
				displayInstanceOf("Shape");
				break;
			case 3:
				System.out.println("\nInformation of all 2D shapes added\n");
				displayInstanceOf("2DShape");
				break;
			case 4:
				System.out.println("\nInformation of all 3D shapes added\n");
				displayInstanceOf("3DShape");
				break;
			case 5:
				displayInstanceOfSpecificShape();
				break;
			case 6:
				displayInstanceOf("ShapeWithIndex");
				removeShape();
				break;
			case 7:
				System.out.println("Thank You !!!!\n\n GOOD BYE");
				return;
			
			default: 
				System.out.println("Invalid Choice\n\n");
				break;
			}
		} while (true);
	}

	private void removeShape() {
		int index = sc.nextInt();
		shapes.remove(index);
	}

	private void displayInstanceOf(String className) {
		switch (className) {
		case "Shape":
			shapes.forEach(System.out::println);
			break;
		case "ShapeWithIndex":
			IntStream.range(0, shapes.size())
					.forEach(index -> System.out.println(String.format("%d. %s", index, shapes.get(index))));
			break;
		case "2DShape":
			shapes.stream().filter(shape -> shape instanceof TwoDShape).forEach(System.out::println);
			break;
		case "3DShape":
			shapes.stream().filter(shape -> shape instanceof ThreeDShape).forEach(System.out::println);
			break;
		}
		System.out.println();
	}

	private void displayInstanceOfSpecificShape() {
		printAvailableShapes();
		Shapes selectedShape = availableShapes[sc.nextInt() - 1];

		switch (selectedShape) {
		case CIRCLE:
			shapes.stream().filter(shape -> shape instanceof Circle).forEach(System.out::println);
			break;
		case RECTANGLE:
			shapes.stream().filter(shape -> shape instanceof Rectangle).forEach(System.out::println);
			break;
		case TRIANGLE:
			shapes.stream().filter(shape -> shape instanceof Triangle).forEach(System.out::println);
			break;
		case CYLINDER:
			shapes.stream().filter(shape -> shape instanceof Cylinder).forEach(System.out::println);
			break;
		case RECTANGULAR_SOLID:
			shapes.stream().filter(shape -> shape instanceof RectangularSolid).forEach(System.out::println);
			break;
		case CUBE:
			shapes.stream().filter(shape -> shape instanceof Cube).forEach(System.out::println);
			break;
		}
		System.out.println();
	}

	private void addShape() {
		printAvailableShapes();

		Shapes selectedShape = availableShapes[sc.nextInt() - 1];
		Shape shapeToBeAdded = null;

		switch (selectedShape) {
		case CIRCLE:
			shapeToBeAdded = new Circle();
			break;
		case RECTANGLE:
			shapeToBeAdded = new Rectangle();
			break;
		case TRIANGLE:
			shapeToBeAdded = new Triangle();
			break;
		case CUBE:
			shapeToBeAdded = new Cube();
			break;
		case RECTANGULAR_SOLID:
			shapeToBeAdded = new RectangularSolid();
			break;
		case CYLINDER:
			shapeToBeAdded = new Cylinder();
			break;

		default:
			System.out.println("Invalid Input");
		}

		if (shapeToBeAdded != null) {
			shapes.add(shapeToBeAdded);
			shapeToBeAdded.initializeShape(sc);
		}
	}

	private void printAvailableShapes() {
		System.out.println("\nSelect shape from the list:");
		Stream.of(availableShapes)
				.forEach(shape -> System.out.println(String.format("%s. %s", shape.getIndex(), shape)));
	}

}
