//package main;

import java.util.Scanner;

public interface Shape {
	void initializeShape(Scanner sc);
}
