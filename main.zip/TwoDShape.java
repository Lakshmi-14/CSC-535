//package main;

public interface TwoDShape extends Shape {

	public double getArea();
	public double getPerimeter();
}
