//package main;

import java.util.Scanner;

public class Circle implements TwoDShape {

	private int radius;

	public Circle() {
	}

	public Circle(int radius) {
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	@Override
	public double getArea() {
		return Math.PI * radius * radius;
	}

	@Override
	public double getPerimeter() {
		return 2D * Math.PI * radius;
	}
	
	@Override
	public void initializeShape(Scanner sc) {
		System.out.println("Enter radius: ");
		setRadius(sc.nextInt());
	}

	@Override
	public String toString() {
		return "Circle ["+" Area=" + getArea() + ", Circumference=" + getPerimeter() + "]";
	}
	
	public static void main(String[] args){
		Circle c1 = new Circle();
		Scanner sc = new Scanner(System.in);
		c1.initializeShape(sc);
		System.out.println(" The Circle properties are : ");
		System.out.println(c1.toString());
		return ;
	}
	
}
