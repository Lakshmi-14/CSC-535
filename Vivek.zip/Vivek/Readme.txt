/*

Author : Vivek
OS: Ubuntu
Dependencies : g++
execution : ./<file_without_extension>

*/