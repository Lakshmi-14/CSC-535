#include <bits/stdc++.h>
struct Connection {
        int src, dest, weight;
};
struct Network {
        int v_count, c_count;
        struct Connection* connection;
};
struct Network* createNetwork(int v_count, int c_count) {
        struct Network* network = new Network;
        network->v_count = v_count;
        network->c_count = c_count;
        network->connection = new Connection[c_count];
        return network;
}
void BellmanFord(struct Network* network, int src, char* vertices) {
        int v_count = network->v_count;
        int c_count = network->c_count;
        int dist[v_count];
        for (int i = 0; i < v_count; i++)
                dist[i] = INT_MAX;
        dist[src] = 0;
        for (int i = 1; i <= v_count - 1; i++) {
                for (int j = 0; j < c_count; j++) {
                        int u = network->connection[j].src;
                        int v = network->connection[j].dest;
                        int weight = network->connection[j].weight;
                        if (dist[u] != INT_MAX && dist[u] + weight < dist[v])
                                dist[v] = dist[u] + weight;
                }
        }
        for (int i = 0; i < c_count; i++) {
                int u = network->connection[i].src;
                int v = network->connection[i].dest;
                int weight = network->connection[i].weight;
                if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                        printf("Network contains negative weight cycle");
                        return;
                }
        }
        std::cout << "Using Bellmanford Agorithm on Figure-1"<<std::endl;
        std::cout << "path  : distance\n";
        for (int i = 0; i < v_count; ++i)
                std::cout << vertices[src] << "-->" << vertices[i] <<"  :  " << dist[i]<< std::endl;
        return;
}


int main() {
        int v_count = 5;
        int c_count = 10;
        struct Network* network = createNetwork(v_count, c_count);

    char str[10] = "ABCDE";
    int sources[] = {0, 0, 1, 1, 4, 4, 4, 3, 3, 2};
    int destinations[] = {1, 4, 4, 2, 1, 2, 3, 0, 2, 3};
    int weights[] = {10, 5, 3, 1, 3, 9, 2, 7, 6, 4};

    for (int i=0;i<c_count;i++){
        network->connection[i].src = sources[i];
        network->connection[i].dest = destinations[i];
        network->connection[i].weight = weights[i];
    }

        BellmanFord(network, 0, str);
        return 0;
}


//g++ -o main.exe file.cpp

