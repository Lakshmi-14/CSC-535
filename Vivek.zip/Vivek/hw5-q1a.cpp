#include <bits/stdc++.h>
using namespace std;

// min_len finds the minimum length if it's not visited
int min_len(int dist[], bool temp[]) 
{
    int minimum=INT_MAX,index;

    for(int k=0;k<6;k++)
    {
        if(temp[k]==false && dist[k]<=minimum)
        {
            minimum=dist[k];
            index=k;
        }
    }
    return index;
}

void dijkstra(int network[6][6],int src)
{
    // dist array to store shortest lengths 
    // temp array is to store whether the vertex is traversed or not
    int dist[6]; 
    bool temp[6];

    for(int k = 0; k<6; k++)
    {
        dist[k] = INT_MAX;
        temp[k] = false;
    }

    dist[src] = 0; 
    //initialising the distance of source node to 0  

    for(int k = 0; k<6; k++)
    {
        int m=min_len(dist,temp);
        temp[m]=true;
        for(int k = 0; k<6; k++)
        {
            if(!temp[k] && network[m][k] && dist[m]!=INT_MAX && dist[m]+network[m][k]<dist[k])
                dist[k]=dist[m]+network[m][k];
        }
    }


    //Displaying the output
    cout<<"Using Dijkstra algoritm on Figure-1"<<endl;
    cout<<"path\tshortest dist"<<endl;
    string str = "SABCDt";
    for(int k = 0; k<6; k++)
    {
        cout<<str[src] << "--->"<<str[k]<<"  :  "<<dist[k]<<endl;
    }
}

int main()
{
    //this matrix represents the figures
    int network[][6]={
        {0, 4, 6, 0, 0, 0},
        {0, 0, 0, 2, 1, 0},
        {0, 2, 0, 0, 2, 0},
        {0, 0, 0, 0, 1, 3},
        {0, 0, 0, 0, 0, 7},
        {0, 0, 0, 0, 0, 0}
        };
    dijkstra(network,0);
    return 0;
}
