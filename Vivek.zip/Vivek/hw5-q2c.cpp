#include <bits/stdc++.h>
using namespace std;

void BellmanFord(int network[][3], int v_count, int c_count,
                 int src)
{

    int dist[v_count];
    for (int i = 0; i < v_count; i++)
        dist[i] = INT_MAX;

    dist[src] = 0;

    for (int i = 0; i < v_count - 1; i++) {

        for (int j = 0; j < c_count; j++) {
            if (dist[network[j][0]] != INT_MAX && dist[network[j][0]] + network[j][2] <
                               dist[network[j][1]])
                dist[network[j][1]] =
                  dist[network[j][0]] + network[j][2];
        }
    }


    for (int i = 0; i < c_count; i++) {
        int x = network[i][0];
        int y = network[i][1];
        int weight = network[i][2];
        if (dist[x] != INT_MAX &&
                   dist[x] + weight < dist[y])
            cout << "Graph contains negative"
                    " weight cycle"
                 << endl;
    }

    string str = "ABCDEFGHJK";
    std::cout << "Using Bellmanford Agorithm on Figure-3"<<std::endl;
        std::cout << "Path  : distance\n";
        for (int i = 0; i < v_count; ++i)
                std::cout << str[src] << "-->" << str[i] <<"  :  " << dist[i]<< std::endl;
        return;
}

int main()
{
    int v_count = 10; 
    int c_count = 26; 

    int network[][3] = { {0,1,1},{0,4,1}, {1,2,1}, {2,6,1}, {2,5,3}, {2,8,4}, {5,9,1}, {8,3,2}, {3,9,1}, {3,4,5}, {3,7,1}, {4,6,1}, {6,7,1},
    {1,0,1},{4,0,1}, {2,1,1}, {6,2,1}, {5,2,3}, {8,2,4}, {9,5,1}, {3,8,2}, {9,3,1}, {4,3,5}, {7,3,1}, {6,4,1}, {7,6,1} };

    BellmanFord(network, v_count, c_count, 0);
    return 0;
}


