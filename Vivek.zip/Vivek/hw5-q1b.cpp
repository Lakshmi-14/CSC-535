#include <bits/stdc++.h>
using namespace std;

// min_len finds the minimum length if it's not visited
int min_len(int dist[], bool temp[]) 
{
    int minimum=INT_MAX,index;

    for(int k=0;k<5;k++)
    {
        if(temp[k]==false && dist[k]<=minimum)
        {
            minimum=dist[k];
            index=k;
        }
    }
    return index;
}

void dijkstra(int network[5][5],int src)
{
    // dist array to store shortest lengths 
    // temp array is to store whether the vertex is traversed or not
    int dist[5]; 
    bool temp[5];

    for(int k = 0; k<5; k++)
    {
        dist[k] = INT_MAX;
        temp[k] = false;
    }

    dist[src] = 0; 
    //initialising the distance of source node to 0  

    for(int k = 0; k<5; k++)
    {
        int m=min_len(dist,temp);
        temp[m]=true;
        for(int k = 0; k<5; k++)
        {
            if(!temp[k] && network[m][k] && dist[m]!=INT_MAX && dist[m]+network[m][k]<dist[k])
                dist[k]=dist[m]+network[m][k];
        }
    }


    //Displaying the output
    cout <<"Using Dijsktra algorithm on Figure-2"<<endl;
    cout<<"path\tShortest distance"<<endl;
    string str = "ABCDE";
    for(int k = 0; k<5; k++)
    {
        cout<<str[src] << "--->"<<str[k]<<"  :  "<<dist[k]<<endl;
    }
}

int main()
{
    int network[][5]={
        {0, 10, 0, 0, 5},
        {0, 0, 1, 0, 2},
        {0, 0, 0, 4, 0},
        {7, 0, 6, 0, 0},
        {0, 3, 9, 2, 0}
};
    dijkstra(network,0);
    return 0;
}
